import faiss
import numpy as np

from modules.embeddings import generate_embeddings


class VectorStore:
    """In-memory FAISS index for document chunks."""

    def __init__(self):
        self.index = None
        self.chunks = []

    def build(self, chunks):
        if not chunks:
            raise ValueError("There are no text chunks to index.")

        texts = [chunk["text"] for chunk in chunks]
        embeddings = np.asarray(
            generate_embeddings(texts),
            dtype="float32",
        )

        dimension = embeddings.shape[1]
        # Embeddings are normalized, so inner product is cosine similarity.
        self.index = faiss.IndexFlatIP(dimension)
        self.index.add(embeddings)
        self.chunks = chunks

    def search(self, question, top_k=4):
        if self.index is None or not self.chunks:
            return []

        query_vector = np.asarray(
            generate_embeddings([question]),
            dtype="float32",
        )
        k = min(top_k, self.index.ntotal)
        scores, indices = self.index.search(query_vector, k)

        results = []
        for score, chunk_index in zip(scores[0], indices[0]):
            if chunk_index < 0:
                continue
            item = self.chunks[int(chunk_index)].copy()
            item["score"] = float(score)
            results.append(item)

        return results
