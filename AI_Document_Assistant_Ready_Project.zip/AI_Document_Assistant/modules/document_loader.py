from io import BytesIO
from pathlib import Path

from docx import Document
from pypdf import PdfReader


def load_document(uploaded_file):
    """Extract text and source metadata from an uploaded PDF, DOCX, or TXT."""
    filename = uploaded_file.name
    extension = Path(filename).suffix.lower()
    file_bytes = uploaded_file.getvalue()
    sections = []

    if extension == ".pdf":
        reader = PdfReader(BytesIO(file_bytes))
        for page_number, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            if text.strip():
                sections.append({
                    "text": text,
                    "source": filename,
                    "page": page_number,
                })

    elif extension == ".docx":
        document = Document(BytesIO(file_bytes))
        paragraphs = [
            paragraph.text.strip()
            for paragraph in document.paragraphs
            if paragraph.text.strip()
        ]
        text = "\n".join(paragraphs)
        if text:
            sections.append({
                "text": text,
                "source": filename,
                "page": None,
            })

    elif extension == ".txt":
        text = file_bytes.decode("utf-8-sig", errors="replace")
        if text.strip():
            sections.append({
                "text": text,
                "source": filename,
                "page": None,
            })
    else:
        raise ValueError("Unsupported file type. Upload PDF, DOCX, or TXT.")

    if not sections:
        raise ValueError(
            f"No readable text found in {filename}. "
            "If it is a scanned PDF, OCR support is required."
        )

    return sections
