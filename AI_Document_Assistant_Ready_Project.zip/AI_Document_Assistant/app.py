import streamlit as st

from modules.document_loader import load_document
from modules.text_splitter import split_documents
from modules.vector_store import VectorStore
from modules.qa_engine import answer_question

st.set_page_config(
    page_title="AI Document Assistant",
    page_icon="📚",
    layout="wide",
)

if "vector_store" not in st.session_state:
    st.session_state.vector_store = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "processed_files" not in st.session_state:
    st.session_state.processed_files = []

st.title("📚 AI Document Assistant")
st.caption("Upload documents, ask questions, and get answers grounded in your files.")
st.divider()

with st.sidebar:
    st.header("📁 Your documents")
    uploads = st.file_uploader(
        "Choose PDF, DOCX, or TXT files",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
        help="For the first version, use text-based PDFs. Scanned PDFs need OCR.",
    )

    if st.button("Process documents", type="primary", use_container_width=True):
        if not uploads:
            st.warning("Please upload at least one document.")
        else:
            try:
                with st.spinner("Reading documents..."):
                    documents = []
                    for upload in uploads:
                        documents.extend(load_document(upload))

                with st.spinner("Splitting text into chunks..."):
                    chunks = split_documents(documents)

                if not chunks:
                    st.error("No readable text was found in the uploaded files.")
                else:
                    with st.spinner("Creating embeddings and search index..."):
                        store = VectorStore()
                        store.build(chunks)

                    st.session_state.vector_store = store
                    st.session_state.processed_files = [f.name for f in uploads]
                    st.session_state.chat_history = []
                    st.success(
                        f"Ready! Processed {len(uploads)} file(s) "
                        f"and created {len(chunks)} searchable chunks."
                    )
            except Exception as exc:
                st.error(f"Document processing failed: {exc}")

    st.divider()
    st.subheader("Processed files")
    if st.session_state.processed_files:
        for filename in st.session_state.processed_files:
            st.write(f"📄 {filename}")
    else:
        st.caption("No documents processed yet.")

    if st.button("Clear conversation", use_container_width=True):
        st.session_state.chat_history = []
        st.rerun()

if st.session_state.vector_store is None:
    left, right = st.columns([1.2, 1])
    with left:
        st.subheader("Ask questions about your files")
        st.write(
            "Upload one or more documents in the sidebar, then select "
            "**Process documents** to build your searchable knowledge base."
        )
        st.markdown(
            "- Get answers based on your uploaded documents\n"
            "- See the source file and page for retrieved passages\n"
            "- Ask follow-up questions during the current session"
        )
    with right:
        st.info(
            "**How it works**\n\n"
            "Document text → chunks → embeddings → FAISS search → "
            "Groq language model → answer with sources"
        )
else:
    st.subheader("💬 Chat with your documents")

    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("sources"):
                with st.expander("Sources used"):
                    for source in message["sources"]:
                        page_text = (
                            f"Page {source['page']}"
                            if source.get("page") is not None
                            else "Document"
                        )
                        st.markdown(
                            f"**{source['source']}** · {page_text} "
                            f"· similarity {source['score']:.2f}"
                        )
                        preview = source["text"].strip()
                        st.caption(preview[:700] + ("..." if len(preview) > 700 else ""))

    question = st.chat_input("Ask a question about your uploaded documents...")
    if question:
        st.session_state.chat_history.append(
            {"role": "user", "content": question}
        )
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            try:
                with st.spinner("Searching your documents and preparing an answer..."):
                    answer, sources = answer_question(
                        question,
                        st.session_state.vector_store,
                    )
                st.markdown(answer)
                if sources:
                    with st.expander("Sources used"):
                        for source in sources:
                            page_text = (
                                f"Page {source['page']}"
                                if source.get("page") is not None
                                else "Document"
                            )
                            st.markdown(f"**{source['source']}** · {page_text}")
                            st.caption(source["text"][:700])
                st.session_state.chat_history.append(
                    {
                        "role": "assistant",
                        "content": answer,
                        "sources": sources,
                    }
                )
            except Exception as exc:
                error_text = f"Sorry, I couldn't generate an answer: {exc}"
                st.error(error_text)
                st.session_state.chat_history.append(
                    {"role": "assistant", "content": error_text, "sources": []}
                )
